


// TODO! (for my reminder only...)

// convert the json data into a real object
//_extractElementsWithMirrors(className, jsonData);

//    ClassMirror requiredClass = currentMirrorSystem().isolate.rootLibrary.classes[className];
//    var newInstance = requiredClass.newInstance("", []);
//    
//    
//    newInstance.then((InstanceMirror instance) {
//      
//      jsonMap.keys.forEach((key) {
//        print(key);
//        if (instance.type.setters.containsKey(key)) {
//          instance.setField(key, jsonMap[key]); 
//        }        
//      }); // for each key
//      this.instance = instance.reflectee;
//    }); // transform