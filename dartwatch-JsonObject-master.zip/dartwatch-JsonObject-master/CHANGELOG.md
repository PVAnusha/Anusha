# Changelog

## 1.0.19

- Added a `recursive` parameter to constructors to allow for disabling recursive conversion to JsonObjects.

## 1.0.18+2 07/11/2013

- Doc fixes.

## 1.0.18 07/11/2013

- Changed stringify to encode
- Removed meta package requirement
- All tests passing with 0.8.10.3_r29803

## 1.0.17 17/Sept/2013

- Added @proxy
- Migrated from dart:json to dart:convert library
- All tests passing with 0.7.2.1_r27268